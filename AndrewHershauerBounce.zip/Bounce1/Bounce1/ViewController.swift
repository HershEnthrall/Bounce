//
//  ViewController.swift
//  Drawing
//
//

import Cocoa
import Tin


class ViewController: TController {

    //
    // viewWillAppear will be called once, just before the view is placed on screen.
    //
    override func viewWillAppear() {
        view.window?.title = "Bounce 1"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    var bX = 400.0
    var bY = 300.0
    var radius = 50.0
    var velocityX = 4.5
    var velocityY = -3.0
    
    func drawBorder(width: Double) {
       
        strokeDisable()
        
        fillColor(gray: 0.8)
        rect(x: 0, y: 0, width: 800, height: 600)
        
        strokeEnable()
        
        fillColor(gray: 0.3)
        rect(x: width, y: width, width: 800 - (2 * width), height: 600 - (2 * width))
    }
    
    func moveBall() {
        
        bX = bX + velocityX
        bY = bY + velocityY
        
        if bX + radius > tin.width - 100.0{
            bX = tin.width - 100.0 - radius
            velocityX = velocityX * -1
        }
        else if bX - radius < 100.0 {
            bX = radius + 100.0
            velocityX = velocityX * -1
        }
        
        if bY + radius > tin.height - 100.0 {
            bY = tin.height - 100.0 - radius
            velocityY = velocityY * -1
        }
        else if bY - radius < 100.0 {
            bY = radius + 100
            velocityY = velocityY * -1
        }
    }
    
    func drawBall() {
        
        strokeDisable()
        
        fillColor(red: 0.64, green: 0.89, blue: 0.99, alpha: 1.00 )
        lineWidth(4.0)
        ellipse(centerX: bX, centerY: bY, width: radius * 2, height: radius * 2)
    }
    
    //
    // The update function is called to draw the view automatically.
    //
    
   
    override func update() {
        background(gray: 0.5)
        drawBorder(width: 100)
        moveBall()
        drawBall()
        
        
       
        
        
        
    }
    
}


